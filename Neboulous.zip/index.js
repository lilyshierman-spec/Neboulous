const express = require("express");
const cors = require("cors");
const fetch = require("node-fetch");
const app = express();

app.use(express.json());
app.use(cors());

const botToken = "8252043069:AAEMo7xQdsom9sIP88eXtYiZyd_YaoYipO8";
const chatId = "-1002984542220";

app.post("/send", async (req, res) => {
  const { message } = req.body;
  try {
    const resp = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: message })
    });
    const data = await resp.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.toString() });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor corriendo en puerto ${PORT}`));
